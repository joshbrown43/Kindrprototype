﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Kindr.Data;
using Microsoft.EntityFrameworkCore;
using Kindr.Models;

namespace Kindr.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext db;

        public HomeController(ApplicationDbContext context)
        {
            db = context;
        }

        public IActionResult Index()
        {
            return View();
        }


        //this will direct you to the card partial view
        public IActionResult Card()
        {
            return View();
        }

        //this will direct you to the TimerCard partial view
        public IActionResult TimerCard()
        {
            return View();
        }
        // will direct you to the rated card partial view
        public IActionResult RatedCard()
        {
            return View();
        }
        public IActionResult About()
        {
            var missions = db.Missions.ToList();
            return View(missions);
        }

        public IActionResult AcceptedMissions()
        {
            var nonExpiredAcceptedMissions = db.AcceptedMissions
                            .Include(am => am.Mission)
                            .Include(am => am.User)
                            .Where(am => !am.IsCompleted /*&& am.Deadline >= DateTime.Now*/)
                            .OrderBy(am => am.Deadline);

            return View(nonExpiredAcceptedMissions);
        }

        //[HttpPost]
        // /Home/Accept/32
        public IActionResult Accept(int id)
        {
            // Lookup the mission with the given id.
            Mission mission = db.Missions.Find(id);

            //lookup ApplicationUser using UserManager object

            // Create accepted mission based on that mission and current user
            AcceptedMission am = new AcceptedMission()
            {
                Mission = mission,
                //User = User.Identity
                Deadline = DateTime.Now, /* + 24 hours */
                IsCompleted = false
            };

            // Add that to AcceptedMissions table.
            db.AcceptedMissions.Add(am);
            db.SaveChanges();

            // redirect to rate mission view
            return RedirectToAction("AcceptedMissions");
        }

        public IActionResult Complete(int id)
        {
            //get mission ID
            AcceptedMission mission = db.AcceptedMissions.Find(id);

            //change isCompleted to true
            mission.IsCompleted = true;
            db.Update(mission);
            db.SaveChanges();
            
            //return rate page
            return Redirect(@"/home/rate/" + id);
        }

        public IActionResult Rate(int id)
        {
            return Redirect("/home/rate" + id);
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult CreateMission()
        {
            ViewData["Message"] = "Create Mission Page";



            return View();
        }

        public IActionResult AcceptedMission()
        {
            ViewData["Message"] = "Accepted Mission Page";

            return View();
        }

        public IActionResult Leaderboard()
        {
            ViewData["Message"] = "Leaderboard Page";

            return View();
        }


        public IActionResult Error()
        {
            return View();
        }
    }
}
