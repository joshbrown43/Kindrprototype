﻿// Write your Javascript code.



// Initialize collapse button
$(".button-collapse").sideNav();

//Slider JS




//Below is the code that makes the countdown timer on the cards
function Timer() {
    var now = new Date();
    var hrs = 23 - now.getHours();
    var mins = 59 - now.getMinutes();
    var secs = 59 - now.getSeconds();
    //these if statements will put a placeholder 0 so the clock does not get mis alligned
    if (hrs < 10) {
        hrs = "0" + hrs;
    }
    if (mins < 10) {
        mins = "0" + mins;
    }
    if (secs < 10) {
        secs = "0" + secs;
    }

    var str = hrs + ":" + mins + ":" + secs;
    $(".timeCountDown").text(str);
}

    //ends code for the card timer


function main() {
    setInterval(Timer, 1000);
}



$(document).ready(main)