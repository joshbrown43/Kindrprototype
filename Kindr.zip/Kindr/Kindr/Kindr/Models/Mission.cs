﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kindr.Models
{
    public class Mission
    {
        public int ID { get; set; }
        public string What { get; set; }
        public string Who { get; set; }
        public string Where { get; set; }
        public string TimeLevel { get; set; }
        public string MoneyLevel { get; set; }
        public bool RequiresTravel { get; set; }

        public ApplicationUser Creator { get; set; }
    }
}
