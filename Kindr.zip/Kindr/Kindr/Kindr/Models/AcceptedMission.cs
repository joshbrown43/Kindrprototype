﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kindr.Models
{
    public class AcceptedMission
    {
        public int ID { get; set; }
        public Mission Mission { get; set; }
        public ApplicationUser User { get; set; }
        public DateTime Deadline { get; set; }
        public bool IsCompleted { get; set; }
        public int? Rating { get; set; }
        
    }
}
