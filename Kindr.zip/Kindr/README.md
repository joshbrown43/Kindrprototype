# Kindr
An asp.net core web app for promoting acts of kindness
